# FIXME
# def test_proxy_config(protocol, ip_address, port):
#     pass
