"""JobFunnel base package init, we keep module version here.
"""

__version__ = "4.0.0"
